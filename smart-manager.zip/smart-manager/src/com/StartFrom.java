/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

/**
 *
 * @author Sazon
 */
public class StartFrom {
    public static void main(String[] args) {
        CreatLogin login = new CreatLogin();
        login.setVisible(true);
    }
}
